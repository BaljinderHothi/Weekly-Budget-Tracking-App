package com.example.budgetapplication;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class AddPurchaseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_purchase);

        EditText amountEditText = findViewById(R.id.entAmount);
        Spinner categorySpinner = findViewById(R.id.spinnerCategory);
        Button addButton = findViewById(R.id.btnAdd);
        Button backButton = findViewById(R.id.btnBack);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.category_array,
                android.R.layout.simple_spinner_item
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(adapter); // Layout of spinner list (use of array/Strings.xml)

        addButton.setOnClickListener(view -> {
            String amountText = amountEditText.getText().toString();
            Double amount = null;
            try {
                amount = Double.parseDouble(amountText);
            } catch (NumberFormatException e) {
                logEvent("input_error", -99.00);
            }

            String category = categorySpinner.getSelectedItem().toString();
            logEvent(category, amount);
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });

        backButton.setOnClickListener(view -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        });
    }
    private void logEvent(String category, Double amount) {
        // Read the existing file content
        String existingContent = readJsonData();
        JSONArray jsonArray;
        try {
            // Try to parse the existing content as a JSON array
            jsonArray = new JSONArray(existingContent);
        } catch (JSONException e) {
            // If not valid JSON (or empty), start with a new JSON array
            jsonArray = new JSONArray();
        }

        // Create a new JSON object for the log event
        JSONObject logObject = new JSONObject();
        try {
            logObject.put("amount", amount);
            logObject.put("category", category);

            // Add the new event to the JSON array
            jsonArray.put(logObject);

            // Convert the updated JSON array to string
            String jsonString = jsonArray.toString();

            // Write the updated JSON string back to the file
            FileOutputStream fos = openFileOutput("appLogs.json", MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(fos);
            osw.write(jsonString);
            osw.close();
        } catch (JSONException | IOException e) {
            e.printStackTrace();
        }
    }

    private String readJsonData() {
        StringBuilder jsonBuilder = new StringBuilder();
        try {
            FileInputStream fis = openFileInput("appLogs.json");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String line;
            while ((line = br.readLine()) != null) {
                jsonBuilder.append(line);
            }
            br.close(); // Ensure the BufferedReader is closed after use
        } catch (IOException e) {
            e.printStackTrace();
        }
        return jsonBuilder.toString();
    }
}