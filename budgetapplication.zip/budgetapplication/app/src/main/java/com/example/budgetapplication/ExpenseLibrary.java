package com.example.budgetapplication;

public class ExpenseLibrary {
    static double[][] expenses = {
            {}, // Food
            {}, // Amenities
            {}, // Transportation
            {}, // Other
    }; // Expenses will be separated by category in the respective order: Food, Amenities, Transportation, Other
    static double weeklyExpense;
    static double foodTotal;
    static double amenitiesTotal;
    static double transportationTotal;
    static double otherTotal;
    public static void updateWeeklyExpense(double newExpense) {
        weeklyExpense += newExpense;
        double[] foodArray = new double[expenses[0].length+1];
        System.arraycopy(expenses[0], 0, foodArray, 0, expenses[0].length);
        foodArray[foodArray.length - 1] = newExpense;
        expenses[0] = foodArray;
    }
    static double getWeeklyExpense() {
        return weeklyExpense;
    }

    static double getFoodTotal() {
        return foodTotal;
    }

    static double getAmenitiesTotal() {
        return amenitiesTotal;
    }

    static double getTransportationTotal() {
        return transportationTotal;
    }

    static double getOtherTotal() {
        return otherTotal;
    }

}
