package com.example.budgetapplication;

import android.content.Context;

import org.json.JSONObject;

import java.io.FileOutputStream;
import java.io.OutputStreamWriter;

public class JsonLogger {

    public static void logData(Context context, String filename, JSONObject jsonObject) {
        FileOutputStream fileOutputStream = null;
        OutputStreamWriter outputStreamWriter = null;

        try {
            fileOutputStream = context.openFileOutput(filename, Context.MODE_PRIVATE);
            outputStreamWriter = new OutputStreamWriter(fileOutputStream);
            outputStreamWriter.write(jsonObject.toString());
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (outputStreamWriter != null) {
                try {
                    outputStreamWriter.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
